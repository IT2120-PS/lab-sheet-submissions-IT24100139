setwd('F:\\sliit\\2nd year\\1 sem\\Probability and Statistics - IT2120\\week 10\\Lab 08-20250925\\IT24100139')

# Read laptop bag weights data
laptop_data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
attach(laptop_data)

# (1.)
pop_mean_weight <- mean(Weight.kg.)
pop_sd_weight <- sd(Weight.kg.)
cat("Laptop Bag Weights - Population Mean:", pop_mean_weight, "\n")
cat("Laptop Bag Weights - Population Standard Deviation:", pop_sd_weight, "\n\n")

# (2.)
set.seed(456) # For reproducible results
weight_samples <- matrix(nrow = 6, ncol = 25)
weight_sample_means <- numeric(25)
weight_sample_sds <- numeric(25)

for(i in 1:25) {
  s <- sample(Weight.kg., 6, replace = TRUE)
  weight_samples[, i] <- s
  weight_sample_means[i] <- mean(s)
  weight_sample_sds[i] <- sd(s)
}

# Create results table for weights
weight_results <- data.frame(
  Sample = 1:25,
  Mean = round(weight_sample_means, 4),
  SD = round(weight_sample_sds, 4)
)

print("Laptop Bag Weights - Sample Results:")
print(weight_results)
cat("\n")

# (3.) 
mean_weight_sample_means <- mean(weight_sample_means)
sd_weight_sample_means <- sd(weight_sample_means)

cat("Mean of Sample Means (Weights):", mean_weight_sample_means, "\n")
cat("Standard Deviation of Sample Means (Weights):", sd_weight_sample_means, "\n")

