setwd('F:\\sliit\\2nd year\\1 sem\\Probability and Statistics - IT2120\\week 11\\IT24100139')

# Exercise

# i. 
baking_times <- rnorm(25, mean = 45, sd = 2)
print(baking_times)

# ii. 
test_result <- t.test(baking_times, mu = 46, alternative = "less")
print(test_result)


